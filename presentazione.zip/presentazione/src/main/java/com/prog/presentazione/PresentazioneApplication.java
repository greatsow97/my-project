package com.prog.presentazione;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PresentazioneApplication {

	public static void main(String[] args) {
		SpringApplication.run(PresentazioneApplication.class, args);
	}

}
