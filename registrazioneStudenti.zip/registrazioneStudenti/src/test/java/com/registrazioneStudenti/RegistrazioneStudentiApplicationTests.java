package com.registrazioneStudenti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrazioneStudentiApplicationTests {

	@Test
	void contextLoads() {
	}

}
