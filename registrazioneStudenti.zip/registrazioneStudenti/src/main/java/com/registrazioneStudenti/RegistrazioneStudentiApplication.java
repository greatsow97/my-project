package com.registrazioneStudenti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrazioneStudentiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrazioneStudentiApplication.class, args);
	}

}
