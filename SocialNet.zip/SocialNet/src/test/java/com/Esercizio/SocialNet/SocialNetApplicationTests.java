package com.Esercizio.SocialNet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialNetApplicationTests {

	@Test
	void contextLoads() {
	}

}
