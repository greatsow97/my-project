package com.Esercizio.SocialNet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialNetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialNetApplication.class, args);
	}

}
